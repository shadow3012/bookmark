import typer
import json
from pathlib import Path

# Initialize the Typer app
app = typer.Typer()

# Define the path for the bookmarks file
BOOKMARKS_FILE = Path("bookmarks.json")

# Function to load bookmarks from the file
def load_data():
    if BOOKMARKS_FILE.exists():
        with open(BOOKMARKS_FILE, "r") as f:
            return json.load(f)
    return {}

# Function to save bookmarks to the file
def save_data(data):
    with open(BOOKMARKS_FILE, "w") as f:
        json.dump(data, f, indent=4)

# Command to add a new bookmark
@app.command()
def add(title: str, url: str):
    '''Add a new bookmark with a title and URL.'''
    data = load_data()
    data[title] = url
    save_data(data)
    typer.echo(f"Bookmark '{title}' has been successfully added.")

# Command to list all bookmarks
@app.command()
def list():
    '''Display all saved bookmarks.'''
    data = load_data()
    if not data:
        typer.echo("No bookmarks found.")
        return
    typer.echo("Bookmarks:")
    for title, url in data.items():
        typer.echo(f"{title}: {url}")

# Command to delete a bookmark by title
@app.command()
def delete(title: str):
    '''Remove a bookmark by its title.'''
    data = load_data()
    if title in data:
        del data[title]
        save_data(data)
        typer.echo(f"Bookmark '{title}' has been deleted.")
    else:
        typer.echo(f"Bookmark '{title}' not found.")

# Command to display the help guide
@app.command()
def help():
    '''Show a guide on how to use the bookmarks CLI.'''
    typer.echo("""
               Bookmarks CLI Guide:
               

               Commands:
               1- Help - Display this help guide.
               2- Add [TITLE] [URL] - Add a new bookmark with a title and URL.
               3- Delete [TITLE] - Remove a bookmark by title.
               4- List - Display all saved bookmarks.
               
               """)

# Entry point of the CLI application
if __name__ == "__main__":
    app()